<?php
return [
    'adminEmail' => 'info.sis.placas@movidelnor.gob.ec',
    'supportEmail' => 'info.sis.placas@movidelnor.gob.ec',
    'senderEmail' => 'noreply@movidelnor.gob.ec',
    'senderName' => 'movidelnor.gob.ec mailer',
    'user.passwordResetTokenExpire' => 3600,
];
