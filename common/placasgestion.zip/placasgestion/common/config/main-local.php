<?php
return [
    'components' => [
        'db' => [
            'class' => 'yii\db\Connection',
            'dsn' => 'mysql:host=localhost;dbname=placas_mancomunidad',
            'username' => 'root',
            'password' => '20160502*MovidelNor.EP',
            'charset' => 'utf8',
        ],
        'mailer' => [
		'class' => 'yii\swiftmailer\Mailer',
		'viewPath' => '@common/mail',
		'transport' => [
			'class' => 'Swift_SmtpTransport',
			'encryption' => 'tls',
			'host' => 'mail.movidelnor.gob.ec',
			'port' => '587',
			'username' => 'info.sis.placas@movidelnor.gob.ec',
			'password' => 'notemetas.2010',
		],
		
	],
    ],
];
