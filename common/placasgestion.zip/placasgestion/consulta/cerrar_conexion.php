<?php
	mysqli_close($conexion);
?>